class_name Pickup
extends Area3D
## Health pack (+40 HP) or ammo box (+60 rounds).

enum Kind { HEALTH, AMMO }

@export var kind: Kind = Kind.HEALTH

var _mesh: MeshInstance3D
var _t := 0.0


func _ready() -> void:
	collision_layer = 0
	collision_mask = 1
	var cs := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = 1.2
	cs.shape = sh
	cs.position.y = 0.8
	add_child(cs)

	var bm := BoxMesh.new()
	bm.size = Vector3(0.5, 0.5, 0.5)
	var mat := StandardMaterial3D.new()
	var c := Color(0.2, 0.9, 0.3) if kind == Kind.HEALTH else Color(1.0, 0.75, 0.15)
	mat.albedo_color = c
	mat.emission_enabled = true
	mat.emission = c
	mat.emission_energy_multiplier = 0.6
	bm.material = mat
	_mesh = MeshInstance3D.new()
	_mesh.mesh = bm
	_mesh.position.y = 0.8
	add_child(_mesh)
	body_entered.connect(_on_body)


func _process(delta: float) -> void:
	_t += delta
	_mesh.rotation.y += delta * 2.0
	_mesh.position.y = 0.8 + sin(_t * 3.0) * 0.1


func _on_body(body: Node3D) -> void:
	if not (body is Player):
		return
	var p := body as Player
	if kind == Kind.HEALTH:
		if p.health >= p.max_health:
			return
		p.heal(40.0)
	else:
		p.weapon.add_ammo(60)
	Sfx.play("pickup")
	queue_free()
