class_name MapBuilder
extends RefCounted
## MAP 01 - ABANDONED CITY, built in code (no assets needed).
## Expanded 320x320 open-world combat zone. Two crossing roads (x and z in [-7, 7]) with abandoned vehicles and barriers
## (both in group "cover" for enemy AI). Buildings fill the four quadrants.


static func build(parent: Node3D) -> void:
	var quality := int(GameData.settings["quality"])
	_environment(parent, quality)

	# Ground + roads
	_box(parent, Vector3(0, -0.5, 0), Vector3(320, 1, 320), Color(0.30, 0.28, 0.25))
	_visual(parent, Vector3(0, 0.03, 0), Vector3(14, 0.06, 320), Color(0.13, 0.13, 0.14))
	_visual(parent, Vector3(0, 0.03, 0), Vector3(320, 0.06, 14), Color(0.13, 0.13, 0.14))
	_visual(parent, Vector3(0, 0.07, 0), Vector3(0.2, 0.02, 320), Color(0.75, 0.65, 0.2))
	_visual(parent, Vector3(0, 0.07, 0), Vector3(320, 0.02, 0.2), Color(0.75, 0.65, 0.2))

	# Boundary walls (invisible)
	for w in [[Vector3(0, 5, 161), Vector3(324, 10, 2)], [Vector3(0, 5, -161), Vector3(324, 10, 2)],
			[Vector3(161, 5, 0), Vector3(2, 10, 324)], [Vector3(-161, 5, 0), Vector3(2, 10, 324)]]:
		_collider_only(parent, w[0], w[1])

	_buildings(parent)
	_vehicles_and_barriers(parent)
	_open_world_props(parent, quality)


static func _environment(parent: Node3D, quality: int) -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.32, 0.42, 0.58)
	sky_mat.sky_horizon_color = Color(0.78, 0.66, 0.55)
	sky_mat.ground_horizon_color = Color(0.78, 0.66, 0.55)
	sky_mat.ground_bottom_color = Color(0.25, 0.22, 0.2)
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.8
	if quality >= 2:
		env.fog_enabled = true
		env.fog_light_color = Color(0.75, 0.68, 0.6)
		env.fog_density = 0.0025
		env.volumetric_fog_enabled = quality >= 3
		env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	parent.add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-40, -35, 0)
	sun.light_color = Color(1.0, 0.9, 0.75)
	sun.shadow_enabled = quality >= 1
	sun.directional_shadow_max_distance = 60.0
	parent.add_child(sun)


static func _buildings(parent: Node3D) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 1234
	var mats: Array[StandardMaterial3D] = []
	for c in [Color(0.42, 0.40, 0.37), Color(0.36, 0.33, 0.30), Color(0.47, 0.42, 0.36), Color(0.30, 0.31, 0.33)]:
		var m := StandardMaterial3D.new()
		m.albedo_color = c
		mats.append(m)
	var roof := StandardMaterial3D.new()
	roof.albedo_color = Color(0.2, 0.2, 0.21)

	for sx in [-1, 1]:
		for sz in [-1, 1]:
			for i in 4:
				for j in 4:
					if rng.randf() < 0.2:
						continue  # empty lot = rubble / open space
					var w := rng.randf_range(9.0, 13.0)
					var d := rng.randf_range(9.0, 13.0)
					var h := rng.randf_range(6.0, 16.0)
					var pos := Vector3(sx * (20.0 + 16.0 * i), h / 2.0, sz * (20.0 + 16.0 * j))
					var body := _box(parent, pos, Vector3(w, h, d), Color.WHITE)
					var mi: MeshInstance3D = body.get_child(0)
					(mi.mesh as BoxMesh).material = mats[rng.randi() % mats.size()]
					# dark roof slab for variety
					var rs := MeshInstance3D.new()
					var rb := BoxMesh.new()
					rb.size = Vector3(w * 0.7, 0.4, d * 0.7)
					rb.material = roof
					rs.mesh = rb
					rs.position = Vector3(0, h / 2.0 + 0.2, 0)
					body.add_child(rs)


static func _vehicles_and_barriers(parent: Node3D) -> void:
	var car_colors := [Color(0.35, 0.1, 0.1), Color(0.15, 0.25, 0.35), Color(0.4, 0.38, 0.2), Color(0.2, 0.2, 0.2)]
	var cars := [Vector3(-5.5, 0, 22), Vector3(-5.5, 0, -18), Vector3(-5.5, 0, -46), Vector3(-5.5, 0, -68),
			Vector3(5.5, 0, 10), Vector3(5.5, 0, -30), Vector3(5.5, 0, -60)]
	for i in cars.size():
		var p: Vector3 = cars[i]
		var body := _box(parent, p + Vector3(0, 0.65, 0), Vector3(2.0, 1.3, 4.4), car_colors[i % car_colors.size()])
		body.rotation.y = deg_to_rad((i * 37) % 20 - 10)
		body.add_to_group("cover")

	var barriers := [Vector3(5, 0, 50), Vector3(5, 0, 28), Vector3(5, 0, -12), Vector3(5, 0, -38),
			Vector3(-5, 0, 40), Vector3(-5, 0, 0), Vector3(-5, 0, -26), Vector3(-5, 0, -52),
			Vector3(20, 0, 5), Vector3(-22, 0, -5), Vector3(38, 0, 5), Vector3(-45, 0, -5)]
	for p: Vector3 in barriers:
		var body := _box(parent, p + Vector3(0, 0.55, 0), Vector3(3.0, 1.1, 0.7), Color(0.5, 0.5, 0.48))
		body.add_to_group("cover")


# ---------- helpers ----------
static func _box(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	bm.material = mat
	mi.mesh = bm
	body.add_child(mi)
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	body.add_child(cs)
	parent.add_child(body)
	return body


static func _visual(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	bm.material = mat
	mi.mesh = bm
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)


static func _collider_only(parent: Node3D, pos: Vector3, size: Vector3) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	body.add_child(cs)
	parent.add_child(body)


# Expanded outskirts: low-cost procedural tree lines, rocks and distant ridges.
# Mesh-only foliage keeps mobile collision and physics overhead low.
static func _open_world_props(parent: Node3D, quality: int) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 84217
	var trunk_mat := StandardMaterial3D.new()
	trunk_mat.albedo_color = Color(0.20, 0.15, 0.10)
	var leaf_mat := StandardMaterial3D.new()
	leaf_mat.albedo_color = Color(0.12, 0.23, 0.13)
	var rock_mat := StandardMaterial3D.new()
	rock_mat.albedo_color = Color(0.27, 0.28, 0.26)
	var count := 44 if quality <= 1 else 76
	for i in count:
		var x := rng.randf_range(-150.0, 150.0)
		var z := rng.randf_range(-150.0, 150.0)
		# Keep the central city streets and mission spawn area readable.
		if absf(x) < 78.0 and absf(z) < 78.0:
			continue
		var trunk := MeshInstance3D.new()
		var tm := CylinderMesh.new()
		tm.top_radius = 0.16
		tm.bottom_radius = 0.25
		tm.height = rng.randf_range(2.2, 3.5)
		tm.material = trunk_mat
		trunk.mesh = tm
		trunk.position = Vector3(x, tm.height * 0.5, z)
		parent.add_child(trunk)
		var crown := MeshInstance3D.new()
		var cm := SphereMesh.new()
		cm.radius = rng.randf_range(1.1, 1.8)
		cm.height = cm.radius * 2.0
		cm.material = leaf_mat
		crown.mesh = cm
		crown.position = Vector3(x, tm.height + cm.radius * 0.55, z)
		parent.add_child(crown)
	for i in 34:
		var rock := MeshInstance3D.new()
		var rm := SphereMesh.new()
		rm.radius = rng.randf_range(0.7, 2.0)
		rm.height = rm.radius * 1.1
		rm.material = rock_mat
		rock.mesh = rm
		rock.position = Vector3(rng.randf_range(-150, 150), rm.radius * 0.45, rng.randf_range(-150, 150))
		rock.scale = Vector3(rng.randf_range(1.0, 2.0), 0.55, rng.randf_range(0.8, 1.5))
		parent.add_child(rock)
