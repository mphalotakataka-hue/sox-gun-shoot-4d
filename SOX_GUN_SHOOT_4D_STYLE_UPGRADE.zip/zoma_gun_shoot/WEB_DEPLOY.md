# Deploy ZOMA GUN SHOOT to CrazyGames (HTML5)

## 1. Export the web build (Godot 4.3 or newer)
1. Editor > Manage Export Templates > download/install templates for your Godot version.
2. Project > Export > preset **Web** (already in export_presets.cfg).
   - Thread Support: **OFF**   (CrazyGames fails the threaded build: "Cross Origin Isolation / SharedArrayBuffer missing")
   - Extensions Support: OFF
3. Export Project -> `build/web/index.html`  (keep the name `index.html`; do not rename other files).

## 2. Test locally
Run from a web server, not by double-clicking the file:
    cd build/web
    python3 -m http.server 8000
Open http://localhost:8000 . Check: menu, mouse capture, play mission 1, audio, save/progress.

## 3. Package
Zip the CONTENTS of `build/web` so index.html is at the root of the zip.
Limits (basic launch): initial download / total size <= 50 MB, <= 1500 files.
This project has no art/audio files, so the engine (.wasm) is almost all of the size.

## 4. Submit
1. Create an account at the CrazyGames Developer Portal -> Submit a game -> HTML5.
2. Upload the zip, use the Preview/QA tool, add title, description, cover images, controls text.
3. Submit. Basic Launch needs no SDK. If metrics are good you are invited to Full Launch
   (CrazyGames SDK, gameplayStart/Stop events, ads, PEGI 12 content check, monetisation).

## Desktop controls (web)
Click to capture mouse | WASD move | mouse look | LMB fire | RMB aim | R reload | Space jump | Shift sprint | C/Ctrl crouch | Esc pause
Touch devices (phones) automatically get the on-screen controls.

---
# Phone-only route (no computer): GitHub builds it for you
1. Make a free GitHub account (browser or GitHub app). Create a new repository (e.g. zoma-gun-shoot).
2. Upload ALL project files so `project.godot` is at the top level of the repo
   (Add file > Upload files; or create each file). Also create the file
   `.github/workflows/export.yml` (Add file > Create new file, type that full path) and paste the workflow text.
3. Open the Actions tab -> "Export Web build" -> wait for the green tick (a few minutes).
   If it is red, open the run, copy the error text and send it to Claude.
4. Open the finished run -> Artifacts -> download `zoma-gun-shoot-web` (a zip with index.html at the top).
5. In your phone browser (use "Desktop site"), open the CrazyGames Developer Portal, Submit a game -> HTML5, upload that zip.
Tip: if Godot 4.3 images are outdated, change "4.3" in export.yml to the newest godot-ci tag.
