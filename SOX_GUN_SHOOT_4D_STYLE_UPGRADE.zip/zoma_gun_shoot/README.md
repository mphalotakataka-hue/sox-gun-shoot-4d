# SOX GUN SHOOT — Immersive Battlefield Upgrade

Godot 4.x project. Import `project.godot` and run the project.

## What this upgrade changes

### Dual camera
- Press **V** on keyboard to switch between third-person and first-person.
- On Android, tap the **CAM** HUD button.
- Third-person keeps the over-the-shoulder camera and visible soldier.
- First-person hides the third-person body and shows a lightweight camera-mounted rifle model.
- Aim mode still works in either view.

### Expanded battlefield
- Expands the playable ground and boundary from 160×160 to 320×320 world units.
- Keeps the existing abandoned-city combat area and its roads, buildings, vehicles and cover.
- Adds procedural low-cost tree lines, rocks and outskirts to make the map feel more open.
- The added foliage is visual-only to reduce mobile physics cost.

### Mobile graphics
- Keeps the Compatibility renderer for broad Android support.
- Uses procedural sky, directional shadows and distance fog according to the existing graphics setting.
- Added scenery is generated from simple meshes; this is a mobile-friendly foundation, not photorealistic art.

## Android controls
- Left virtual joystick: move
- Swipe right side: look
- FIRE / AIM / RELOAD / JUMP / CROUCH / SPRINT: combat controls
- **CAM**: switch first-person / third-person
- II: pause

## Exact Android setup
1. Keep a backup of your original project ZIP.
2. Download and extract this ZIP using ZArchiver.
3. In Godot, choose **Import**, then select the extracted `zoma_gun_shoot/project.godot`.
4. Let Godot finish importing assets and scripts.
5. Open the project and press Play.
6. Start a mission. Tap **CAM** to enter first-person; tap it again to return to third-person.
7. Test the expanded outskirts by moving away from the central city.
8. If the phone struggles, open Settings in the game and choose the lower graphics quality option.

## Important limitations
“4D” is used here as a creative label for a more immersive 3D experience; Godot games are rendered in 3D, not a literal fourth spatial dimension. This is a procedural upgrade, not a finished AAA/photorealistic game. The first-person weapon is a simple procedural model. Imported rigged soldier GLB assets, authored animation clips, detailed PBR textures, optimized terrain streaming, and true ragdoll physics remain future upgrades.

The project has not been run in the Godot editor in this environment. Please test it on your device before replacing your original project.
