class_name Weapon
extends Node
## Hitscan weapon (default stats = ZR-01 assault rifle).
## Shoots from the camera centre so the crosshair is always where bullets go.
## Any collider with a `take_damage(amount)` method is damaged.

signal ammo_changed(mag: int, reserve: int)
signal reload_started
signal reload_finished
signal fired

@export var weapon_name := "ZR-01"
@export var damage := 25.0
@export var fire_rate := 9.0          # rounds per second
@export var mag_size := 30
@export var reserve_start := 120
@export var reload_time := 2.0
@export var hip_spread := 2.5         # degrees
@export var aim_spread := 0.6
@export var max_range := 120.0

var mag := 30
var reserve := 120
var reloading := false
var firing := false
var aiming := false

var _cooldown := 0.0
var _camera: Camera3D
var _muzzle: Node3D
var _exclude: Array[RID] = []
var _tracer_mat: StandardMaterial3D
var _flash_mat: StandardMaterial3D


func setup(camera: Camera3D, muzzle: Node3D, shooter_rid: RID) -> void:
	_camera = camera
	_muzzle = muzzle
	_exclude = [shooter_rid]
	# Apply purchased upgrades (saved locally)
	mag_size += int(GameData.upgrades["mag"]) * 5
	damage *= 1.0 + 0.1 * int(GameData.upgrades["damage"])
	reload_time *= pow(0.9, int(GameData.upgrades["reload"]))
	mag = mag_size
	reserve = reserve_start
	_tracer_mat = _glow(Color(1.0, 0.72, 0.22))
	_flash_mat = _glow(Color(1.0, 0.6, 0.2))
	ammo_changed.emit(mag, reserve)


func _physics_process(delta: float) -> void:
	_cooldown = maxf(_cooldown - delta, 0.0)
	if firing and _cooldown <= 0.0 and not reloading:
		_try_shoot()


func _try_shoot() -> void:
	if mag <= 0:
		reload()  # auto-reload on empty
		return
	mag -= 1
	_cooldown = 1.0 / fire_rate
	ammo_changed.emit(mag, reserve)
	fired.emit()
	Sfx.play("shot", -4.0)
	_fire_ray()


func _fire_ray() -> void:
	var spread := deg_to_rad(aim_spread if aiming else hip_spread)
	var b := _camera.global_transform.basis
	var dir := (-b.z).rotated(b.x, randf_range(-spread, spread)) \
			.rotated(b.y, randf_range(-spread, spread)).normalized()
	var from := _camera.global_position
	var to := from + dir * max_range

	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.exclude = _exclude
	var hit := _camera.get_world_3d().direct_space_state.intersect_ray(query)

	var end := to
	if not hit.is_empty():
		end = hit.position
		var collider = hit.collider
		if collider and collider.has_method("take_damage"):
			collider.take_damage(damage)
			if collider.has_method("show_blood_hit"):
				collider.show_blood_hit(end, hit.normal)
		_spawn_impact(end, hit.normal)
	_spawn_tracer(_muzzle.global_position, end)
	_spawn_flash(_muzzle.global_position)


func reload() -> void:
	if reloading or mag >= mag_size or reserve <= 0:
		return
	reloading = true
	reload_started.emit()
	Sfx.play("reload")
	await get_tree().create_timer(reload_time).timeout
	var take := mini(mag_size - mag, reserve)
	mag += take
	reserve -= take
	reloading = false
	ammo_changed.emit(mag, reserve)
	reload_finished.emit()


func add_ammo(amount: int) -> void:
	reserve += amount
	ammo_changed.emit(mag, reserve)


# ---------- Simple effects (cheap for mobile) ----------
func _glow(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = color
	return m


func _spawn_tracer(from: Vector3, to: Vector3) -> void:
	var length := from.distance_to(to)
	if length < 0.2:
		return
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.025, 0.025, length)
	bm.material = _tracer_mat
	mi.mesh = bm
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	get_tree().current_scene.add_child(mi)
	mi.global_position = (from + to) / 2.0
	mi.look_at(to, Vector3.UP if absf((to - from).normalized().y) < 0.99 else Vector3.RIGHT)
	get_tree().create_timer(0.05).timeout.connect(mi.queue_free)


func _spawn_impact(pos: Vector3, normal: Vector3) -> void:
	if int(GameData.settings["quality"]) == 0:
		return
	_spawn_ball(pos + normal * 0.02, 0.055, _flash_mat, 0.12)
	for i in range(3):
		var spark := MeshInstance3D.new()
		var mesh := SphereMesh.new()
		mesh.radius = 0.018
		mesh.height = 0.036
		mesh.material = _flash_mat
		spark.mesh = mesh
		get_tree().current_scene.add_child(spark)
		spark.global_position = pos + normal * 0.04
		var drift := normal * randf_range(0.12, 0.3) + Vector3(randf_range(-0.12, 0.12), randf_range(0.02, 0.16), randf_range(-0.12, 0.12))
		var tw := spark.create_tween()
		tw.tween_property(spark, "global_position", spark.global_position + drift, 0.12)
		tw.parallel().tween_property(spark, "scale", Vector3.ZERO, 0.13)
		tw.tween_callback(spark.queue_free)


func _spawn_flash(pos: Vector3) -> void:
	_spawn_ball(pos, 0.1, _flash_mat, 0.04)


func _spawn_ball(pos: Vector3, r: float, mat: Material, life: float) -> void:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = r
	sm.height = r * 2.0
	sm.radial_segments = 8
	sm.rings = 4
	sm.material = mat
	mi.mesh = sm
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	get_tree().current_scene.add_child(mi)
	mi.global_position = pos
	get_tree().create_timer(life).timeout.connect(mi.queue_free)
