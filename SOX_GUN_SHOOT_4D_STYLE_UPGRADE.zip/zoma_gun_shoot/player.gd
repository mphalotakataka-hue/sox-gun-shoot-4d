class_name Player
extends CharacterBody3D
## ZOMA: third-person character. Builds its own nodes so no scene setup is needed.
## Placeholder capsule body; swap `body` contents for the real rigged model later.

@export_group("Speed")
@export var walk_speed := 2.5
@export var run_speed := 5.0
@export var sprint_speed := 7.5
@export var crouch_speed := 1.8
@export var acceleration := 40.0
@export var jump_velocity := 5.5
@export var gravity := 18.0

@export_group("Body")
@export var stand_height := 1.8
@export var crouch_height := 1.1
@export var radius := 0.35

@export_group("Camera")
@export var look_sensitivity := 0.005
@export var min_pitch := -60.0
@export var max_pitch := 30.0
@export var normal_arm := 3.5
@export var aim_arm := 1.6
@export var normal_fov := 70.0
@export var aim_fov := 52.0

## For the animation system later: idle, walk, run, sprint, crouch, air
var state := "idle"
var move_input := Vector2.ZERO  # from joystick
var sprint_on := false
var crouching := false
var aiming := false
var fire_held := false
var dead := false
var max_health := 100.0
var health := 100.0
var weapon: Weapon

signal health_changed(current: float, maximum: float)
signal died

var _jump_queued := false
var _step_dist := 0.0
var _bob_t := 0.0
var _look_index := -1
var _yaw := 0.0
var _pitch := -10.0

var _pivot: Node3D
var _arm: SpringArm3D
var _camera: Camera3D
var _fp_weapon: Node3D
var camera_mode := "third_person"
var _body: Node3D
var _mesh: MeshInstance3D
var _capsule_mesh: CapsuleMesh
var _collider: CollisionShape3D
var _visor: MeshInstance3D
var _gun: MeshInstance3D
var _muzzle: Node3D
var _shape: CapsuleShape3D
var _left_arm: Node3D
var _right_arm: Node3D
var _left_leg: Node3D
var _right_leg: Node3D
var _anim_time := 0.0
var _gun_kick := 0.0


func _ready() -> void:
	_build_body()
	_build_camera()
	_apply_height(stand_height)
	weapon = Weapon.new()
	add_child(weapon)
	weapon.setup(_camera, _muzzle, get_rid())
	weapon.fired.connect(_on_fired)


func _build_body() -> void:
	_shape = CapsuleShape3D.new()
	_shape.radius = radius
	_collider = CollisionShape3D.new()
	_collider.shape = _shape
	add_child(_collider)

	_body = Node3D.new()
	add_child(_body)

	_capsule_mesh = CapsuleMesh.new()
	_capsule_mesh.radius = radius
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.08, 0.08, 0.1)  # black combat armour
	_capsule_mesh.material = mat
	_mesh = MeshInstance3D.new()
	_mesh.mesh = _capsule_mesh
	_body.add_child(_mesh)

	# Tactical silhouette layered over the capsule placeholder.
	var armour := StandardMaterial3D.new()
	armour.albedo_color = Color(0.07, 0.085, 0.095)
	armour.metallic = 0.25
	var fabric := StandardMaterial3D.new()
	fabric.albedo_color = Color(0.025, 0.03, 0.035)
	var skin := StandardMaterial3D.new()
	skin.albedo_color = Color(0.32, 0.22, 0.16)
	var red := StandardMaterial3D.new()
	red.albedo_color = Color(0.85, 0.1, 0.1)
	_add_player_box(Vector3(0.62, 0.72, 0.34), Vector3(0, 1.12, 0), armour)
	_add_player_box(Vector3(0.48, 0.22, 0.38), Vector3(0, 1.35, -0.01), fabric)
	var head := MeshInstance3D.new()
	var head_mesh := SphereMesh.new()
	head_mesh.radius = 0.17
	head_mesh.height = 0.34
	head_mesh.material = skin
	head.mesh = head_mesh
	head.position = Vector3(0, 1.66, 0)
	_body.add_child(head)
	_add_player_box(Vector3(0.4, 0.14, 0.4), Vector3(0, 1.79, 0), fabric)
	_add_player_box(Vector3(0.36, 0.07, 0.08), Vector3(0, 1.66, -0.15), red)
	_left_arm = _make_player_limb(Vector3(-0.43, 1.15, -0.02), Vector3(0.19, 0.58, 0.2), armour)
	_right_arm = _make_player_limb(Vector3(0.43, 1.15, -0.02), Vector3(0.19, 0.58, 0.2), armour)
	_left_leg = _make_player_limb(Vector3(-0.17, 0.48, 0), Vector3(0.23, 0.62, 0.25), fabric)
	_right_leg = _make_player_limb(Vector3(0.17, 0.48, 0), Vector3(0.23, 0.62, 0.25), fabric)

	# Red "visor" box so you can see which way ZOMA faces (-Z is forward)
	_visor = MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(0.4, 0.12, 0.2)
	box.material = red
	_visor.mesh = box
	_visor.position = Vector3(0, 1.55, -0.3)
	_body.add_child(_visor)

	# Placeholder ZR-01 rifle held at the right side
	_gun = MeshInstance3D.new()
	var gun_mesh := BoxMesh.new()
	gun_mesh.size = Vector3(0.1, 0.14, 0.8)
	var gun_mat := StandardMaterial3D.new()
	gun_mat.albedo_color = Color(0.15, 0.15, 0.17)
	gun_mesh.material = gun_mat
	_gun.mesh = gun_mesh
	_gun.position = Vector3(0.28, 1.2, -0.45)
	_body.add_child(_gun)
	_add_gun_detail(Vector3(0.055, 0.05, 0.28), Vector3(0, 0.095, -0.05), gun_mat)
	_add_gun_detail(Vector3(0.07, 0.2, 0.12), Vector3(0, -0.15, 0.18), gun_mat)
	_add_gun_detail(Vector3(0.12, 0.08, 0.16), Vector3(0, 0.11, 0.08), gun_mat)
	_muzzle = Node3D.new()
	_muzzle.position = Vector3(0, 0, -0.45)  # tip of the rifle
	_gun.add_child(_muzzle)


func _add_player_box(size: Vector3, pos: Vector3, material: Material) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh.material = material
	node.mesh = mesh
	node.position = pos
	_body.add_child(node)
	return node


func _make_player_limb(pos: Vector3, size: Vector3, material: Material) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = pos
	_body.add_child(pivot)
	var limb := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh.material = material
	limb.mesh = mesh
	limb.position.y = -size.y * 0.34
	pivot.add_child(limb)
	return pivot


func _add_gun_detail(size: Vector3, pos: Vector3, material: Material) -> void:
	var part := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh.material = material
	part.mesh = mesh
	part.position = pos
	_gun.add_child(part)


func _build_camera() -> void:
	_pivot = Node3D.new()
	add_child(_pivot)

	_arm = SpringArm3D.new()
	_arm.spring_length = normal_arm
	_arm.margin = 0.3
	_arm.add_excluded_object(get_rid())
	_pivot.add_child(_arm)

	_camera = Camera3D.new()
	_camera.fov = normal_fov
	_camera.h_offset = 0.6  # over-the-shoulder
	_arm.add_child(_camera)
	_camera.current = true
	_build_first_person_weapon()
	_apply_camera_mode()



func _build_first_person_weapon() -> void:
	# Lightweight camera-mounted rifle silhouette for first-person mode.
	_fp_weapon = Node3D.new()
	_fp_weapon.position = Vector3(0.30, -0.25, -0.58)
	_camera.add_child(_fp_weapon)
	var dark := StandardMaterial3D.new()
	dark.albedo_color = Color(0.075, 0.085, 0.09)
	dark.metallic = 0.45
	var body := MeshInstance3D.new()
	var receiver := BoxMesh.new()
	receiver.size = Vector3(0.13, 0.15, 0.48)
	receiver.material = dark
	body.mesh = receiver
	_fp_weapon.add_child(body)
	var barrel := MeshInstance3D.new()
	var barrel_mesh := CylinderMesh.new()
	barrel_mesh.top_radius = 0.025
	barrel_mesh.bottom_radius = 0.025
	barrel_mesh.height = 0.42
	barrel_mesh.material = dark
	barrel.mesh = barrel_mesh
	barrel.rotation.x = deg_to_rad(90)
	barrel.position.z = -0.40
	_fp_weapon.add_child(barrel)
	var mag := MeshInstance3D.new()
	var mag_mesh := BoxMesh.new()
	mag_mesh.size = Vector3(0.09, 0.22, 0.13)
	mag_mesh.material = dark
	mag.mesh = mag_mesh
	mag.position = Vector3(0, -0.17, -0.02)
	mag.rotation.x = deg_to_rad(-12)
	_fp_weapon.add_child(mag)
	var sight := MeshInstance3D.new()
	var sight_mesh := BoxMesh.new()
	sight_mesh.size = Vector3(0.07, 0.06, 0.12)
	sight_mesh.material = dark
	sight.mesh = sight_mesh
	sight.position = Vector3(0, 0.105, -0.04)
	_fp_weapon.add_child(sight)


func toggle_camera_mode() -> void:
	camera_mode = "first_person" if camera_mode == "third_person" else "third_person"
	_apply_camera_mode()


func _apply_camera_mode() -> void:
	var first_person := camera_mode == "first_person"
	_body.visible = not first_person
	_fp_weapon.visible = first_person
	_arm.spring_length = 0.0 if first_person else (aim_arm if aiming else normal_arm)
	_camera.h_offset = 0.0 if first_person else (0.45 if aiming else 0.6)
	_pivot.position.y = _shape.height * (0.91 if first_person else 0.9)


# ---------- Input from HUD ----------
func set_move_input(v: Vector2) -> void:
	move_input = v

func request_jump() -> void:
	_jump_queued = true

func toggle_crouch() -> void:
	crouching = not crouching
	if crouching:
		sprint_on = false

func toggle_sprint() -> void:
	sprint_on = not sprint_on
	if sprint_on:
		crouching = false

func set_aiming(value: bool) -> void:
	aiming = value

func get_yaw() -> float:
	return _yaw

func set_firing(value: bool) -> void:
	fire_held = value

func reload() -> void:
	weapon.reload()

func take_damage(amount: float) -> void:
	if dead:
		return
	health = maxf(health - amount, 0.0)
	health_changed.emit(health, max_health)
	Sfx.play("hurt", -4.0)
	if health <= 0.0:
		dead = true
		fire_held = false
		weapon.firing = false
		died.emit()

func heal(amount: float) -> void:
	if dead:
		return
	health = minf(health + amount, max_health)
	health_changed.emit(health, max_health)

func _on_fired() -> void:
	_pitch = clampf(_pitch + 0.7, min_pitch, max_pitch)
	_yaw += randf_range(-0.004, 0.004)
	_gun_kick = 0.12


func _unhandled_input(event: InputEvent) -> void:
	# Swipe on the right ~60% of the screen to look around.
	if event is InputEventScreenTouch:
		var w := get_viewport().get_visible_rect().size.x
		if event.pressed and _look_index == -1 and event.position.x > w * 0.4:
			_look_index = event.index
		elif not event.pressed and event.index == _look_index:
			_look_index = -1
	elif event is InputEventScreenDrag and event.index == _look_index:
		var sens := look_sensitivity * float(GameData.settings["sensitivity"]) * (0.6 if aiming else 1.0)
		_yaw -= event.relative.x * sens
		_pitch = clampf(_pitch - rad_to_deg(event.relative.y * sens), min_pitch, max_pitch)
	elif event is InputEventMouseMotion and event.device != InputEvent.DEVICE_ID_EMULATION \
			and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		# Desktop / web: mouse look (only while the mouse is captured)
		var ms := look_sensitivity * 0.5 * float(GameData.settings["sensitivity"]) * (0.6 if aiming else 1.0)
		_yaw -= event.relative.x * ms
		_pitch = clampf(_pitch - rad_to_deg(event.relative.y * ms), min_pitch, max_pitch)
	elif event is InputEventMouseButton and event.device != InputEvent.DEVICE_ID_EMULATION:
		if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
			if event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
				Input.mouse_mode = Input.MOUSE_MODE_CAPTURED  # click to start
		elif event.button_index == MOUSE_BUTTON_LEFT:
			fire_held = event.pressed
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			aiming = event.pressed
	elif event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_SPACE: request_jump()
			KEY_C, KEY_CTRL: toggle_crouch()
			KEY_R: reload()
			KEY_V: toggle_camera_mode()


func _keyboard_vector() -> Vector2:
	var v := Vector2.ZERO
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): v.x -= 1
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): v.x += 1
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): v.y -= 1
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): v.y += 1
	return v.limit_length(1.0)


func _physics_process(delta: float) -> void:
	if dead:
		weapon.firing = false
		return
	weapon.firing = fire_held or Input.is_key_pressed(KEY_F)
	weapon.aiming = aiming

	var input := move_input
	if input == Vector2.ZERO:
		input = _keyboard_vector()
	var strength := input.length()

	var sprinting := (sprint_on or Input.is_key_pressed(KEY_SHIFT)) \
			and strength > 0.1 and not crouching
	var target_speed := walk_speed
	if crouching:
		target_speed = crouch_speed
	elif sprinting:
		target_speed = sprint_speed
	elif strength > 0.55:
		target_speed = run_speed

	# Move relative to the camera's facing
	var dir := _pivot.global_transform.basis * Vector3(input.x, 0.0, input.y)
	dir.y = 0.0
	dir = dir.normalized() * minf(strength, 1.0)

	var horiz := Vector2(velocity.x, velocity.z).move_toward(
			Vector2(dir.x, dir.z) * target_speed, acceleration * delta)
	velocity.x = horiz.x
	velocity.z = horiz.y

	if is_on_floor():
		if _jump_queued and not crouching:
			velocity.y = jump_velocity
	else:
		velocity.y -= gravity * delta
	_jump_queued = false

	move_and_slide()

	# Face movement direction (or camera direction while aiming)
	if aiming:
		_body.rotation.y = lerp_angle(_body.rotation.y, _yaw, delta * 14.0)
	elif dir.length() > 0.1:
		var target := atan2(-dir.x, -dir.z)
		_body.rotation.y = lerp_angle(_body.rotation.y, target, delta * 12.0)

	_update_state(horiz.length(), sprinting)
	_animate_character(delta, horiz.length(), sprinting)
	# Footsteps + simple procedural walk bob (placeholder until the rigged model arrives)
	var moving := is_on_floor() and horiz.length() > 0.5
	if moving:
		_bob_t += delta * horiz.length() * 1.8
		_step_dist += delta * horiz.length()
		if _step_dist >= 2.2:
			_step_dist = 0.0
			Sfx.play("step", -14.0 if crouching else (-6.0 if sprinting else -9.0))
		_body.position.y = absf(sin(_bob_t)) * 0.05
	else:
		_step_dist = 1.5
		_body.position.y = lerpf(_body.position.y, 0.0, delta * 10.0)
	_update_camera(delta)
	_apply_height(lerpf(_shape.height, crouch_height if crouching else stand_height, delta * 12.0))


func _animate_character(delta: float, speed: float, sprinting: bool) -> void:
	_anim_time += delta
	_gun_kick = move_toward(_gun_kick, 0.0, delta * 1.8)
	var moving := is_on_floor() and speed > 0.25
	var cycle := sin(_anim_time * (10.0 if sprinting else 7.0))
	var amount := clampf(speed / sprint_speed, 0.0, 1.0)
	_left_leg.rotation.x = cycle * 0.52 * amount
	_right_leg.rotation.x = -cycle * 0.52 * amount
	_left_arm.rotation.x = -cycle * 0.25 * amount - (0.2 if aiming else 0.0)
	_right_arm.rotation.x = cycle * 0.25 * amount - 0.25 - _gun_kick
	if not moving:
		_left_leg.rotation.x = lerpf(_left_leg.rotation.x, 0.0, delta * 8.0)
		_right_leg.rotation.x = lerpf(_right_leg.rotation.x, 0.0, delta * 8.0)


func _update_state(speed: float, sprinting: bool) -> void:
	if not is_on_floor():
		state = "air"
	elif crouching:
		state = "crouch"
	elif speed < 0.2:
		state = "idle"
	elif sprinting:
		state = "sprint"
	elif speed > walk_speed + 0.5:
		state = "run"
	else:
		state = "walk"


func _update_camera(delta: float) -> void:
	_pivot.rotation = Vector3(deg_to_rad(_pitch), _yaw, 0.0)
	_pivot.position.y = _shape.height * 0.9
	var target_arm := 0.0 if camera_mode == "first_person" else (aim_arm if aiming else normal_arm)
	_arm.spring_length = lerpf(_arm.spring_length, target_arm, delta * 10.0)
	_camera.fov = lerpf(_camera.fov, aim_fov if aiming else normal_fov, delta * 10.0)
	var target_offset := 0.0 if camera_mode == "first_person" else (0.45 if aiming else 0.6)
	_camera.h_offset = lerpf(_camera.h_offset, target_offset, delta * 10.0)
	_fp_weapon.position = Vector3(0.30, -0.25, -0.58) + Vector3(0, 0, _gun_kick * 0.45)


func _apply_height(h: float) -> void:
	_shape.height = h
	_capsule_mesh.height = h
	_collider.position.y = h / 2.0
	_mesh.position.y = h / 2.0
	_visor.position.y = h * 0.86
	_gun.position.y = h * 0.66
