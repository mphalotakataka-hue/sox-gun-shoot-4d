class_name Enemy
extends CharacterBody3D
## Black Viper soldier. Finite-state AI: PATROL -> ALERT -> ATTACK <-> COVER -> DEAD.
## Five kinds from the design doc: basic, heavy, sniper, elite, commander.
## Steering uses a simple obstacle ray (no navmesh yet).

signal killed(points: int, pos: Vector3, kind_id: int)

enum State { PATROL, ALERT, ATTACK, COVER, DEAD }
enum Kind { BASIC, HEAVY, SNIPER, ELITE, COMMANDER }

@export var kind: Kind = Kind.BASIC

var player: Player
var waypoints: Array[Vector3] = []
var state := State.PATROL

var max_health := 60.0
var patrol_speed := 1.8
var chase_speed := 4.0
var damage := 6.0
var fire_interval := 0.6
var accuracy := 0.45
var detect_range := 28.0
var attack_range := 18.0
var points := 100
var body_scale := 1.0
var color := Color(0.22, 0.30, 0.20)

var health := 60.0
var _wp := 0
var _wait := 0.0
var _last_known := Vector3.ZERO
var _search_time := 0.0
var _shoot_cd := 1.0
var _los_timer := 0.0
var _sees := false
var _lost_sight := 0.0
var _strafe := 1.0
var _strafe_timer := 0.0
var _cover_pos := Vector3.ZERO
var _cover_wait := 0.0
var _cover_travel := 0.0
var _cover_cd := 0.0
var _move_dir := Vector3.ZERO
var _move_speed := 0.0
var _face_dir := Vector3.ZERO
var _mat: StandardMaterial3D
var _col: CollisionShape3D
var _tracer_mat: StandardMaterial3D
var _left_arm: Node3D
var _right_arm: Node3D
var _left_leg: Node3D
var _right_leg: Node3D
var _head: MeshInstance3D
var _gun: Node3D
var _anim_time := 0.0
var _hit_flash := 0.0


func _ready() -> void:
	_apply_kind()
	_build_model()
	add_to_group("enemies")
	if player:
		player.weapon.fired.connect(_on_player_fired)


func _apply_kind() -> void:
	match kind:
		Kind.HEAVY:
			max_health = 150.0; patrol_speed = 1.5; chase_speed = 2.8; damage = 8.0
			fire_interval = 0.45; accuracy = 0.4; detect_range = 25.0; attack_range = 14.0
			points = 200; body_scale = 1.25; color = Color(0.35, 0.30, 0.25)
		Kind.SNIPER:
			max_health = 50.0; patrol_speed = 1.2; chase_speed = 2.0; damage = 22.0
			fire_interval = 2.2; accuracy = 0.6; detect_range = 45.0; attack_range = 42.0
			points = 250; color = Color(0.30, 0.33, 0.18)
		Kind.ELITE:
			max_health = 90.0; patrol_speed = 2.5; chase_speed = 5.2; damage = 7.0
			fire_interval = 0.4; accuracy = 0.6; detect_range = 32.0; attack_range = 20.0
			points = 300; color = Color(0.40, 0.12, 0.40)
		Kind.COMMANDER:
			max_health = 300.0; patrol_speed = 1.8; chase_speed = 3.4; damage = 10.0
			fire_interval = 0.38; accuracy = 0.55; detect_range = 40.0; attack_range = 24.0
			points = 1000; body_scale = 1.3; color = Color(0.55, 0.10, 0.10)
	# Difficulty (Easy / Medium / Hard)
	var dm := GameData.diff_mult()
	damage *= dm
	accuracy = clampf(accuracy * dm, 0.1, 0.9)
	health = max_health


func _build_model() -> void:
	var s := body_scale
	var armour := StandardMaterial3D.new()
	armour.albedo_color = color
	armour.metallic = 0.28
	armour.roughness = 0.72
	var dark := StandardMaterial3D.new()
	dark.albedo_color = Color(0.055, 0.065, 0.07)
	dark.metallic = 0.55
	var skin := StandardMaterial3D.new()
	skin.albedo_color = Color(0.32, 0.22, 0.16)
	var visor_mat := StandardMaterial3D.new()
	visor_mat.albedo_color = Color(0.9, 0.12, 0.06)
	visor_mat.emission_enabled = true
	visor_mat.emission = Color(0.5, 0.025, 0.01)

	var shape := CapsuleShape3D.new()
	shape.radius = 0.35 * s
	shape.height = 1.8 * s
	_col = CollisionShape3D.new()
	_col.shape = shape
	_col.position.y = 0.9 * s
	add_child(_col)

	# Layered combat silhouette: torso, chest rig, helmet and articulated limbs.
	_add_box(Vector3(0.62, 0.72, 0.34) * s, Vector3(0, 1.12, 0) * s, armour)
	_add_box(Vector3(0.48, 0.24, 0.37) * s, Vector3(0, 1.35, -0.015) * s, dark)
	_add_box(Vector3(0.18, 0.28, 0.20) * s, Vector3(-0.34, 1.12, 0) * s, dark)
	_add_box(Vector3(0.18, 0.28, 0.20) * s, Vector3(0.34, 1.12, 0) * s, dark)

	_head = MeshInstance3D.new()
	var head_mesh := SphereMesh.new()
	head_mesh.radius = 0.17 * s
	head_mesh.height = 0.34 * s
	head_mesh.material = skin
	_head.mesh = head_mesh
	_head.position = Vector3(0, 1.66, 0) * s
	add_child(_head)
	_add_box(Vector3(0.39, 0.14, 0.39) * s, Vector3(0, 1.79, 0) * s, dark)
	_add_box(Vector3(0.34, 0.07, 0.08) * s, Vector3(0, 1.67, -0.15) * s, visor_mat)

	_left_arm = _make_limb(Vector3(-0.43, 1.15, -0.02) * s, Vector3(0.19, 0.58, 0.2) * s, armour)
	_right_arm = _make_limb(Vector3(0.43, 1.15, -0.02) * s, Vector3(0.19, 0.58, 0.2) * s, armour)
	_left_leg = _make_limb(Vector3(-0.17, 0.48, 0) * s, Vector3(0.23, 0.62, 0.25) * s, dark)
	_right_leg = _make_limb(Vector3(0.17, 0.48, 0) * s, Vector3(0.23, 0.62, 0.25) * s, dark)

	_gun = Node3D.new()
	_gun.position = Vector3(0.27, 1.18, -0.42) * s
	add_child(_gun)
	_add_gun_part(_gun, Vector3(0.12, 0.13, 0.68) * s, Vector3(0, 0, 0) * s, dark)
	_add_gun_part(_gun, Vector3(0.075, 0.16, 0.20) * s, Vector3(0, -0.13, 0.12) * s, dark)
	_add_gun_part(_gun, Vector3(0.045, 0.045, 0.48) * s, Vector3(0, 0.045, -0.48) * s, dark)
	_add_gun_part(_gun, Vector3(0.07, 0.18, 0.10) * s, Vector3(0, -0.12, 0.28) * s, dark)

	_tracer_mat = StandardMaterial3D.new()
	_tracer_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_tracer_mat.albedo_color = Color(1.0, 0.3, 0.2)


func _add_box(size: Vector3, pos: Vector3, material: Material) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh.material = material
	node.mesh = mesh
	node.position = pos
	add_child(node)
	return node


func _make_limb(pos: Vector3, size: Vector3, material: Material) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = pos
	add_child(pivot)
	var limb := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh.material = material
	limb.mesh = mesh
	limb.position.y = -size.y * 0.34
	pivot.add_child(limb)
	return pivot


func _add_gun_part(parent: Node3D, size: Vector3, pos: Vector3, material: Material) -> void:
	var part := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh.material = material
	part.mesh = mesh
	part.position = pos
	parent.add_child(part)


# ---------- Main loop ----------
func _physics_process(delta: float) -> void:
	if state == State.DEAD:
		return
	_shoot_cd = maxf(_shoot_cd - delta, 0.0)
	_cover_cd = maxf(_cover_cd - delta, 0.0)
	_update_sight(delta)

	_move_dir = Vector3.ZERO
	_move_speed = 0.0
	_face_dir = Vector3.ZERO
	match state:
		State.PATROL: _do_patrol(delta)
		State.ALERT: _do_alert(delta)
		State.ATTACK: _do_attack(delta)
		State.COVER: _do_cover(delta)
	_apply_movement(delta)
	_animate_soldier(delta)


func _animate_soldier(delta: float) -> void:
	_anim_time += delta
	var speed := Vector2(velocity.x, velocity.z).length()
	var stride := sin(_anim_time * (7.0 if speed > 2.0 else 4.0))
	var amount := clampf(speed / maxf(chase_speed, 0.1), 0.0, 1.0)
	_left_leg.rotation.x = stride * 0.48 * amount
	_right_leg.rotation.x = -stride * 0.48 * amount
	_left_arm.rotation.x = -stride * 0.25 * amount - 0.18
	_right_arm.rotation.x = stride * 0.25 * amount - 0.22
	_gun.rotation.x = lerpf(_gun.rotation.x, -0.06 if state == State.ATTACK else 0.0, delta * 5.0)


func _update_sight(delta: float) -> void:
	_los_timer -= delta
	if _los_timer > 0.0:
		return
	_los_timer = 0.15
	_sees = false
	if player == null or player.dead:
		return
	var to := player.global_position - global_position
	var d := to.length()
	if d > detect_range:
		return
	if state == State.PATROL:
		var flat := Vector3(to.x, 0.0, to.z).normalized()
		if d > 6.0 and (-global_transform.basis.z).dot(flat) < 0.45:
			return  # outside field of view
		if player.crouching and d > detect_range * 0.5:
			return  # crouching halves detection range
	var q := PhysicsRayQueryParameters3D.create(_eye(), player.global_position + Vector3.UP * 1.1)
	q.exclude = [get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	_sees = not hit.is_empty() and hit.collider == player


func _eye() -> Vector3:
	return global_position + Vector3.UP * 1.5 * body_scale


# ---------- States ----------
func _do_patrol(delta: float) -> void:
	if _sees:
		_alert(player.global_position)
		return
	if waypoints.is_empty():
		rotation.y += delta * 0.5  # guard post: scan the area
		return
	if _wait > 0.0:
		_wait -= delta
		return
	var to := waypoints[_wp] - global_position
	to.y = 0.0
	if to.length() < 1.0:
		_wait = randf_range(1.5, 3.0)
		_wp = (_wp + 1) % waypoints.size()
		return
	_move_dir = to
	_move_speed = patrol_speed


func _do_alert(delta: float) -> void:
	if _sees:
		state = State.ATTACK
		_lost_sight = 0.0
		return
	var to := _last_known - global_position
	to.y = 0.0
	if to.length() < 1.5:
		_search_time -= delta
		rotation.y += delta * 1.5  # look around
		if _search_time <= 0.0:
			state = State.PATROL
		return
	_move_dir = to
	_move_speed = chase_speed


func _do_attack(delta: float) -> void:
	if player == null or player.dead:
		state = State.PATROL
		return
	var to := player.global_position - global_position
	to.y = 0.0
	var dist := to.length()
	_face_dir = to
	if _sees:
		_lost_sight = 0.0
		_last_known = player.global_position
	else:
		_lost_sight += delta
		if _lost_sight > 2.0:
			state = State.ALERT
			_search_time = 4.0
			return

	if _cover_cd <= 0.0 and (health < max_health * 0.5 or randf() < delta * 0.08):
		if _try_cover():
			return

	_strafe_timer -= delta
	if _strafe_timer <= 0.0:
		if randf() < 0.5:
			_strafe = -_strafe
		_strafe_timer = randf_range(1.0, 2.5)
	var side := to.normalized().cross(Vector3.UP) * _strafe

	if dist > attack_range or not _sees:
		_move_dir = to
		_move_speed = chase_speed
	elif kind == Kind.SNIPER:
		pass  # snipers hold position
	elif dist < attack_range * 0.35:
		_move_dir = -to.normalized() + side * 0.5
		_move_speed = patrol_speed * 1.3
	else:
		_move_dir = side
		_move_speed = patrol_speed

	if _sees and dist <= attack_range * 1.1 and _shoot_cd <= 0.0:
		_shoot()


func _try_cover() -> bool:
	var best := Vector3.ZERO
	var best_d := 25.0
	var found := false
	for c: Node3D in get_tree().get_nodes_in_group("cover"):
		var away := c.global_position - player.global_position
		away.y = 0.0
		if away.length() < 0.1:
			continue
		var pos := c.global_position + away.normalized() * 1.8  # far side of the cover
		pos.y = global_position.y
		var d := global_position.distance_to(pos)
		if d < best_d:
			best_d = d
			best = pos
			found = true
	if not found:
		return false
	_cover_pos = best
	_cover_wait = randf_range(2.0, 3.5)
	_cover_travel = 6.0
	_cover_cd = 8.0
	state = State.COVER
	return true


func _do_cover(delta: float) -> void:
	_cover_travel -= delta
	var to := _cover_pos - global_position
	to.y = 0.0
	if to.length() > 1.0 and _cover_travel > 0.0:
		_move_dir = to
		_move_speed = chase_speed
		return
	_cover_wait -= delta  # hide behind cover
	if player:
		_face_dir = player.global_position - global_position
	if _cover_wait <= 0.0 or _cover_travel <= -6.0:
		state = State.ATTACK
		_lost_sight = 0.0


# ---------- Combat ----------
func _shoot() -> void:
	_shoot_cd = fire_interval * randf_range(0.9, 1.3)
	var target := player.global_position + Vector3.UP * 1.1
	var dist := global_position.distance_to(player.global_position)
	var chance := clampf(accuracy * (1.15 - dist / (attack_range * 1.8)), 0.08, 0.9)
	if player.crouching:
		chance *= 0.75
	var muzzle := global_position + Vector3.UP * 1.3 * body_scale + (-global_transform.basis.z) * 0.7
	var end := target
	if randf() < chance:
		player.take_damage(damage)
	else:
		end = target + Vector3(randf_range(-1.2, 1.2), randf_range(-0.8, 0.8), randf_range(-1.2, 1.2))
	_tracer(muzzle, end)
	Sfx.play_at("enemy_shot", global_position)


func _tracer(from: Vector3, to: Vector3) -> void:
	var length := from.distance_to(to)
	if length < 0.3:
		return
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.03, 0.03, length)
	bm.material = _tracer_mat
	mi.mesh = bm
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	get_tree().current_scene.add_child(mi)
	mi.global_position = (from + to) / 2.0
	var up := Vector3.UP if absf((to - from).normalized().y) < 0.99 else Vector3.RIGHT
	mi.look_at(to, up)
	get_tree().create_timer(0.06).timeout.connect(mi.queue_free)


func _alert(pos: Vector3) -> void:
	if state == State.DEAD:
		return
	_last_known = pos
	_search_time = 4.0
	if state != State.PATROL:
		return
	state = State.ALERT
	Sfx.play_at("alert", global_position)
	var radius := 50.0 if kind == Kind.COMMANDER else 22.0  # commander coordinates forces
	for e: Enemy in get_tree().get_nodes_in_group("enemies"):
		if e != self and e.global_position.distance_to(global_position) < radius:
			e.hear(pos)


func hear(pos: Vector3) -> void:
	if state == State.PATROL:
		state = State.ALERT
		_last_known = pos
		_search_time = 4.0


func _on_player_fired() -> void:
	if state == State.PATROL and player and global_position.distance_to(player.global_position) < 30.0:
		_alert(player.global_position)


func take_damage(amount: float) -> void:
	if state == State.DEAD:
		return
	health -= amount
	_hit_flash = 0.12
	Sfx.play_at("hit", global_position)
	if player:
		_alert(player.global_position)
	if state == State.ALERT or state == State.PATROL:
		state = State.ATTACK
		_lost_sight = 0.0
	if health <= 0.0:
		_die()


func show_blood_hit(hit_pos: Vector3, hit_normal: Vector3) -> void:
	if int(GameData.settings["quality"]) == 0:
		return
	# Brief stylised red hit particles; lightweight for Android.
	for i in range(5):
		var drop := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		sphere.radius = randf_range(0.018, 0.035)
		sphere.height = sphere.radius * 2.0
		sphere.radial_segments = 6
		sphere.rings = 3
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.55, 0.015, 0.025)
		mat.roughness = 1.0
		sphere.material = mat
		drop.mesh = sphere
		get_tree().current_scene.add_child(drop)
		drop.global_position = hit_pos + hit_normal * 0.025
		var drift := Vector3(randf_range(-0.35, 0.35), randf_range(0.08, 0.45), randf_range(-0.35, 0.35))
		var tw := create_tween()
		tw.tween_property(drop, "global_position", drop.global_position + drift, 0.22)
		tw.parallel().tween_property(drop, "scale", Vector3.ZERO, 0.24)
		tw.tween_callback(drop.queue_free)


func _die() -> void:
	state = State.DEAD
	remove_from_group("enemies")
	_col.set_deferred("disabled", true)
	killed.emit(points, global_position, kind)
	# Stagger, drop to the ground and remain briefly before cleanup.
	var fall := create_tween()
	fall.set_parallel(true)
	fall.tween_property(self, "rotation:x", -PI / 2.0, 0.48).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	fall.tween_property(self, "position:y", maxf(position.y - 0.65, 0.0), 0.48)
	await get_tree().create_timer(4.0).timeout
	queue_free()


# ---------- Movement ----------
func _apply_movement(delta: float) -> void:
	var dir := _move_dir
	if dir.length() > 0.01:
		dir = _avoid(dir.normalized())
	velocity.x = move_toward(velocity.x, dir.x * _move_speed, 20.0 * delta)
	velocity.z = move_toward(velocity.z, dir.z * _move_speed, 20.0 * delta)
	if is_on_floor():
		velocity.y = -0.1
	else:
		velocity.y -= 18.0 * delta
	move_and_slide()

	var face := _face_dir if _face_dir.length() > 0.05 else dir
	if face.length() > 0.05:
		rotation.y = lerp_angle(rotation.y, atan2(-face.x, -face.z), delta * 8.0)


func _avoid(dir: Vector3) -> Vector3:
	var from := global_position + Vector3.UP * 0.6
	var q := PhysicsRayQueryParameters3D.create(from, from + dir * 1.6)
	q.exclude = [get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if hit.is_empty():
		return dir
	var n: Vector3 = hit.normal
	n.y = 0.0
	if n.length() < 0.01:
		return dir
	var slid := dir.slide(n.normalized())
	if slid.length() < 0.2:
		slid = dir.cross(Vector3.UP) * _strafe
	return slid.normalized()
