class_name TouchButton
extends Control
## Round on-screen button that supports true multi-touch
## (hold FIRE while moving with the joystick).

signal button_down
signal button_up
signal pressed  # fired on release

@export var label := ""

## Highlight for toggle states (crouch / sprint)
var lit := false:
	set(value):
		lit = value
		queue_redraw()

var held := false
var _index := -1


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and _index == -1:
			_index = event.index
			held = true
			button_down.emit()
			queue_redraw()
			accept_event()
		elif not event.pressed and event.index == _index:
			_index = -1
			held = false
			button_up.emit()
			pressed.emit()
			queue_redraw()
			accept_event()


func _draw() -> void:
	var c := size / 2.0
	var r := minf(size.x, size.y) / 2.0
	var fill := Color(1, 1, 1, 0.12)
	if held or lit:
		fill = Color(0.9, 0.15, 0.15, 0.55)
	draw_circle(c, r, fill)
	draw_arc(c, r, 0.0, TAU, 40, Color(1, 1, 1, 0.45), 3.0)
	var font := ThemeDB.fallback_font
	var fs := 18
	draw_string(font, Vector2(0, c.y + fs * 0.35), label,
			HORIZONTAL_ALIGNMENT_CENTER, size.x, fs, Color(1, 1, 1, 0.9))
