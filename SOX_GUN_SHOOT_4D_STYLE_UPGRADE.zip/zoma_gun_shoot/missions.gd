class_name Missions
extends RefCounted
## All 7 missions from the design doc.
## Enemy kinds: 0 basic, 1 heavy, 2 sniper, 3 elite, 4 commander.
## Map: player starts at z=+65; north (negative z) is the enemy base. Roads: x in [-7,7] and z in [-7,7].

const LIST := [
	{
		"name": "First Contact", "brief": "Eliminate 3 enemy soldiers",
		"type": "eliminate", "goal": 3,
		"enemies": [[0, Vector3(0, 0, 35)], [0, Vector3(-3, 0, 15)], [0, Vector3(3, 0, -5)]],
	},
	{
		"name": "City Rescue", "brief": "Rescue 3 captured civilians",
		"type": "civilians", "goal": 3,
		"civilians": [Vector3(26, 0, 0), Vector3(-32, 0, -2), Vector3(48, 0, 3)],
		"enemies": [[0, Vector3(0, 0, 25)], [0, Vector3(24, 0, 3)], [0, Vector3(-28, 0, -3)], [2, Vector3(0, 0, -30)]],
	},
	{
		"name": "Silent Operation", "brief": "Reach the enemy facility",
		"type": "reach", "goal": 1, "marker": Vector3(0, 0, -70),
		"enemies": [[0, Vector3(0, 0, 30)], [0, Vector3(4, 0, 0)], [3, Vector3(-3, 0, -25)], [2, Vector3(0, 0, -45)], [0, Vector3(0, 0, -60)]],
	},
	{
		"name": "Lost Technology", "brief": "Recover 3 stolen equipment crates",
		"type": "crates", "goal": 3,
		"crates": [Vector3(30, 0, -3), Vector3(-40, 0, 2), Vector3(0, 0, -45)],
		"enemies": [[0, Vector3(0, 0, 20)], [1, Vector3(32, 0, 3)], [0, Vector3(-38, 0, -2)], [3, Vector3(0, 0, -40)], [2, Vector3(0, 0, -65)]],
	},
	{
		"name": "Enemy Base", "brief": "Disable the enemy communications tower",
		"type": "hold", "goal": 1, "hold_time": 8.0, "marker": Vector3(0, 0, -62),
		"enemies": [[0, Vector3(0, 0, 25)], [1, Vector3(0, 0, -20)], [0, Vector3(2, 0, -45)], [3, Vector3(-4, 0, -50)], [2, Vector3(0, 0, -70)], [0, Vector3(0, 0, -58)]],
	},
	{
		"name": "The Commander", "brief": "Defeat the Black Viper commander",
		"type": "commander", "goal": 1,
		"enemies": [[4, Vector3(0, 0, -55)], [1, Vector3(4, 0, -50)], [1, Vector3(-4, 0, -50)], [0, Vector3(0, 0, -35)], [0, Vector3(0, 0, 10)], [3, Vector3(0, 0, -45)]],
	},
	{
		"name": "Final Stand", "brief": "Eliminate all Black Viper forces",
		"type": "eliminate_all", "goal": 10,
		"enemies": [[4, Vector3(0, 0, -60)], [1, Vector3(5, 0, -40)], [1, Vector3(-5, 0, -40)], [3, Vector3(0, 0, -25)], [3, Vector3(3, 0, -10)], [2, Vector3(0, 0, -50)], [0, Vector3(0, 0, 30)], [0, Vector3(0, 0, 15)], [0, Vector3(-4, 0, 0)], [2, Vector3(0, 0, -70)]],
	},
]
