extends Node
## Autoload "Sfx": all sounds are synthesised in code, so the game has working audio
## with zero asset files. Replace any entry in `sounds` with a real .wav/.ogg later.

const RATE := 22050

var sounds: Dictionary = {}
var _players: Array[AudioStreamPlayer] = []
var _idx := 0
var _music: AudioStreamPlayer


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build_sounds()
	for i in 12:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players.append(p)
	_music = AudioStreamPlayer.new()
	add_child(_music)
	apply_volumes()


func apply_volumes() -> void:
	_music.volume_db = linear_to_db(maxf(float(GameData.settings["music"]), 0.001)) - 8.0


func play(sound: String, vol_db := 0.0) -> void:
	if not sounds.has(sound):
		return
	var p := _players[_idx]
	_idx = (_idx + 1) % _players.size()
	p.stream = sounds[sound]
	p.volume_db = vol_db + linear_to_db(maxf(float(GameData.settings["sfx"]), 0.001))
	p.pitch_scale = randf_range(0.95, 1.05)
	p.play()


func play_at(sound: String, pos: Vector3) -> void:
	var cam := get_viewport().get_camera_3d()
	if cam == null:
		play(sound)
		return
	var d := cam.global_position.distance_to(pos)
	if d > 70.0:
		return
	play(sound, -minf(d * 0.5, 30.0))


func play_music() -> void:
	if _music.playing:
		return
	_music.stream = sounds["music"]
	_music.play()


func stop_music() -> void:
	_music.stop()


# ---------- Synthesis ----------
func _buf(seconds: float) -> PackedFloat32Array:
	var a := PackedFloat32Array()
	a.resize(int(seconds * RATE))
	return a


func _make(samples: PackedFloat32Array, loop := false) -> AudioStreamWAV:
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	var bytes := PackedByteArray()
	bytes.resize(samples.size() * 2)
	for i in samples.size():
		bytes.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32000.0))
	w.data = bytes
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = samples.size()
	return w


func _build_sounds() -> void:
	sounds["shot"] = _make(_shot(1.0, 90.0))
	sounds["enemy_shot"] = _make(_shot(0.7, 140.0))
	sounds["reload"] = _make(_reload())
	sounds["hit"] = _make(_hit())
	sounds["hurt"] = _make(_hurt())
	sounds["step"] = _make(_step())
	sounds["pickup"] = _make(_pickup())
	sounds["alert"] = _make(_alert())
	sounds["announce"] = _make(_announce())
	sounds["victory"] = _make(_notes([523.0, 659.0, 784.0, 1047.0], 0.22, 0.6))
	sounds["defeat"] = _make(_notes([392.0, 349.0, 311.0, 262.0], 0.35, 0.8))
	sounds["music"] = _make(_music_loop(), true)


func _shot(amp: float, freq: float) -> PackedFloat32Array:
	var a := _buf(0.3)
	var lp := 0.0
	for i in a.size():
		var t := float(i) / RATE
		lp += 0.35 * ((randf() * 2.0 - 1.0) - lp)
		a[i] = (lp * exp(-t * 22.0) * 1.4 + sin(TAU * freq * t * exp(-t * 6.0)) * exp(-t * 18.0) * 0.7) * amp
	return a


func _reload() -> PackedFloat32Array:
	var a := _buf(2.0)
	var clicks := [0.15, 0.55, 1.2, 1.7]
	for i in a.size():
		var t := float(i) / RATE
		var v := 0.0
		for c in clicks:
			var dt: float = t - c
			if dt >= 0.0 and dt < 0.06:
				v += (randf() * 2.0 - 1.0) * exp(-dt * 90.0) * 0.5 + sin(TAU * 900.0 * dt) * exp(-dt * 80.0) * 0.3
		a[i] = v
	return a


func _hit() -> PackedFloat32Array:
	var a := _buf(0.12)
	for i in a.size():
		var t := float(i) / RATE
		a[i] = (randf() * 2.0 - 1.0) * exp(-t * 35.0) * 0.5 + sin(TAU * 320.0 * t) * exp(-t * 30.0) * 0.4
	return a


func _hurt() -> PackedFloat32Array:
	var a := _buf(0.25)
	for i in a.size():
		var t := float(i) / RATE
		a[i] = sin(TAU * 150.0 * t) * exp(-t * 12.0) * 0.7 + (randf() * 2.0 - 1.0) * exp(-t * 30.0) * 0.3
	return a


func _step() -> PackedFloat32Array:
	var a := _buf(0.1)
	var lp := 0.0
	for i in a.size():
		var t := float(i) / RATE
		lp += 0.15 * ((randf() * 2.0 - 1.0) - lp)
		a[i] = lp * exp(-t * 45.0) * 1.2
	return a


func _pickup() -> PackedFloat32Array:
	var a := _buf(0.3)
	for i in a.size():
		var t := float(i) / RATE
		var f := 660.0 if t < 0.15 else 990.0
		a[i] = sin(TAU * f * t) * exp(-fmod(t, 0.15) * 18.0) * 0.4
	return a


func _alert() -> PackedFloat32Array:
	var a := _buf(0.35)
	for i in a.size():
		var t := float(i) / RATE
		a[i] = signf(sin(TAU * (500.0 + 400.0 * t / 0.35) * t)) * 0.2 * (1.0 - t / 0.35)
	return a


func _announce() -> PackedFloat32Array:
	var a := _buf(0.6)
	for i in a.size():
		var t := float(i) / RATE
		var tt := fmod(t, 0.3)
		a[i] = sin(TAU * 880.0 * t) * 0.35 * minf(1.0, (0.2 - tt) * 20.0) if tt < 0.2 else 0.0
	return a


func _notes(freqs: Array, note_len: float, tail: float) -> PackedFloat32Array:
	var total := note_len * freqs.size() + tail
	var a := _buf(total)
	for i in a.size():
		var t := float(i) / RATE
		var n := mini(int(t / note_len), freqs.size() - 1)
		var local := t - n * note_len
		var f: float = freqs[n]
		a[i] = (sin(TAU * f * t) * 0.35 + sin(TAU * f * 2.0 * t) * 0.1) * exp(-local * 3.0)
	return a


func _music_loop() -> PackedFloat32Array:
	# 4 s seamless loop: all frequencies fit a whole number of cycles
	var a := _buf(4.0)
	for i in a.size():
		var t := float(i) / RATE
		var tt := fmod(t, 1.0)
		var v := sin(TAU * 55.0 * t) * 0.30
		v += sin(TAU * 82.5 * t) * 0.18 * (0.6 + 0.4 * sin(TAU * 0.5 * t))
		v += sin(TAU * 110.0 * t) * exp(-tt * 5.0) * 0.2
		v += sin(TAU * 165.0 * t) * 0.05 * sin(TAU * 0.25 * t)
		a[i] = v * 0.5
	return a
