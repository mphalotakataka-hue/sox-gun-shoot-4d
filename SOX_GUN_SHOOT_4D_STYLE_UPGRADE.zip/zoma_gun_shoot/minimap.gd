class_name Minimap
extends Control
## Rotating radar. Red = enemies, blue = civilians, yellow = objectives (clamped to the edge).

var player: Player
@export var range_m := 45.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _process(_delta: float) -> void:
	queue_redraw()


func _draw() -> void:
	var c := size / 2.0
	var r := size.x / 2.0
	draw_circle(c, r, Color(0, 0, 0, 0.45))
	draw_arc(c, r, 0.0, TAU, 48, Color(1, 1, 1, 0.5), 2.0)
	if player == null:
		return
	for e: Node3D in get_tree().get_nodes_in_group("enemies"):
		_dot(e.global_position, Color(1, 0.2, 0.2), 4.0, false)
	for n: Node3D in get_tree().get_nodes_in_group("civilians"):
		_dot(n.global_position, Color(0.3, 0.7, 1.0), 4.0, false)
	for o: Node3D in get_tree().get_nodes_in_group("objective"):
		_dot(o.global_position, Color(1, 0.85, 0.1), 5.0, true)
	# Player arrow (always points up)
	draw_colored_polygon(PackedVector2Array([
		c + Vector2(0, -8), c + Vector2(6, 7), c + Vector2(-6, 7)]), Color.WHITE)


func _dot(world: Vector3, col: Color, rad: float, clamp_to_edge: bool) -> void:
	var c := size / 2.0
	var r := size.x / 2.0
	var d := Vector2(world.x - player.global_position.x, world.z - player.global_position.z)
	var s := d.rotated(player.get_yaw()) * (r / range_m)
	if s.length() > r - rad:
		if not clamp_to_edge:
			return
		s = s.normalized() * (r - rad)
	draw_circle(c + s, rad, col)
