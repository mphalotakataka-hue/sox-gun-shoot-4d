extends Node3D
## Gameplay scene: builds the Abandoned City, spawns player/enemies/objectives,
## runs the mission, HUD, mini-map, pause, and victory/defeat screens.

const SPAWN := Vector3(0, 1.0, 65)

var player: Player
var mission: Dictionary
var mission_index := 0
var kills := 0
var score := 0
var collected := 0
var total_enemies := 0
var commander_dead := false
var hold_progress := 0.0

var _ended := false
var _zone: MissionMarker
var _layer: CanvasLayer
var _score_label: Label
var _objective_label: Label
var _ammo_label: Label
var _status_label: Label
var _health_bar: ProgressBar
var _crouch_btn: TouchButton
var _sprint_btn: TouchButton
var _flash: ColorRect
var _panel: PanelContainer
var _last_health := 100.0
var _touch_ui: Array[Control] = []
var _touch_visible := false
var _hint: Label
var _was_captured := false


func _ready() -> void:
	mission_index = clampi(GameData.current_mission, 0, Missions.LIST.size() - 1)
	mission = Missions.LIST[mission_index]

	MapBuilder.build(self)
	player = Player.new()
	player.position = SPAWN
	add_child(player)

	_spawn_enemies()
	_spawn_objectives()
	_spawn_pickups()
	_build_hud()
	_setup_input_mode()

	player.weapon.ammo_changed.connect(_on_ammo_changed)
	player.weapon.reload_started.connect(func(): _status_label.text = "RELOADING...")
	player.weapon.reload_finished.connect(func(): _status_label.text = "")
	player.health_changed.connect(_on_health_changed)
	player.died.connect(_lose)
	_on_ammo_changed(player.weapon.mag, player.weapon.reserve)
	_on_health_changed(player.health, player.max_health)

	Sfx.play_music()
	Sfx.play("announce")
	_status_label.text = "MISSION %02d: %s\n%s" % [mission_index + 1, mission.name.to_upper(), mission.brief]
	get_tree().create_timer(4.0).timeout.connect(func():
		if not _ended and not player.weapon.reloading:
			_status_label.text = "")


func _process(delta: float) -> void:
	_crouch_btn.lit = player.crouching
	_sprint_btn.lit = player.sprint_on
	if _ended:
		return
	# Desktop: releasing the mouse (Esc) pauses the game
	var captured := Input.mouse_mode == Input.MOUSE_MODE_CAPTURED
	if _was_captured and not captured and not get_tree().paused:
		_pause()
	_was_captured = captured
	_hint.visible = not _touch_visible and not captured and _panel == null
	if mission.type == "hold":
		if _zone.player_inside:
			hold_progress += delta
		else:
			hold_progress = maxf(hold_progress - delta * 0.5, 0.0)
		if hold_progress >= float(mission.hold_time):
			_win()
	_score_label.text = "SCORE  %d" % score
	_objective_label.text = _objective_text()


# ---------- Spawning ----------
func _spawn_enemies() -> void:
	total_enemies = mission.enemies.size()
	for entry in mission.enemies:
		var p: Vector3 = entry[1]
		var e := Enemy.new()
		e.kind = entry[0]
		e.player = player
		e.position = p + Vector3(0, 0.05, 0)
		e.waypoints = _make_waypoints(p, entry[0])
		add_child(e)
		e.killed.connect(_on_enemy_killed)


func _make_waypoints(p: Vector3, kind_id: int) -> Array[Vector3]:
	var wps: Array[Vector3] = []
	if kind_id == 2 or kind_id == 4:
		return wps  # snipers and commanders guard their post
	var step := Vector3(8, 0, 0) if absf(p.x) > 15.0 else Vector3(0, 0, 8)
	wps.append(p)
	wps.append(p + step)
	wps.append(p)
	wps.append(p - step)
	return wps


func _spawn_objectives() -> void:
	match mission.type:
		"civilians":
			for pos: Vector3 in mission.civilians:
				_add_marker(MissionMarker.Kind.CIVILIAN, pos, true)
		"crates":
			for pos: Vector3 in mission.crates:
				_add_marker(MissionMarker.Kind.CRATE, pos, true)
		"reach":
			_zone = _add_marker(MissionMarker.Kind.ZONE, mission.marker, true)
		"hold":
			_zone = _add_marker(MissionMarker.Kind.ZONE, mission.marker, false)
			_add_tower(mission.marker)


func _add_marker(k: MissionMarker.Kind, pos: Vector3, emit: bool) -> MissionMarker:
	var m := MissionMarker.new()
	m.kind = k
	m.emit_on_enter = emit
	m.position = pos
	add_child(m)
	m.collected.connect(_on_collected)
	return m


func _add_tower(pos: Vector3) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(1.4, 16.0, 1.4)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.2, 0.2, 0.22)
	bm.material = mat
	mi.mesh = bm
	mi.position = pos + Vector3(0, 8.0, -7.0)
	add_child(mi)
	var top := MeshInstance3D.new()
	var tb := BoxMesh.new()
	tb.size = Vector3(0.6, 0.6, 0.6)
	var tm := StandardMaterial3D.new()
	tm.albedo_color = Color.RED
	tm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	tb.material = tm
	top.mesh = tb
	top.position = pos + Vector3(0, 16.3, -7.0)
	add_child(top)


func _spawn_pickups() -> void:
	for pos in [Vector3(-3, 0, 48), Vector3(3, 0, 5), Vector3(-2, 0, -30)]:
		_add_pickup(Pickup.Kind.HEALTH, pos)
	for pos in [Vector3(3, 0, 38), Vector3(-3, 0, -10), Vector3(2, 0, -48)]:
		_add_pickup(Pickup.Kind.AMMO, pos)


func _add_pickup(k: Pickup.Kind, pos: Vector3) -> void:
	var p := Pickup.new()
	p.kind = k
	p.position = pos
	add_child(p)


# ---------- Mission logic ----------
func _on_enemy_killed(points: int, pos: Vector3, kind_id: int) -> void:
	score += points
	kills += 1
	if kind_id == Enemy.Kind.COMMANDER:
		commander_dead = true
	if randf() < 0.35:
		_add_pickup(Pickup.Kind.HEALTH if randf() < 0.5 else Pickup.Kind.AMMO, Vector3(pos.x, 0, pos.z))
	_check_win()


func _on_collected(m: MissionMarker) -> void:
	collected += 1
	score += 150
	Sfx.play("pickup")
	m.queue_free()
	_check_win()


func _check_win() -> void:
	if _ended:
		return
	var done := false
	match mission.type:
		"eliminate": done = kills >= int(mission.goal)
		"eliminate_all": done = kills >= total_enemies
		"commander": done = commander_dead
		"civilians", "crates", "reach": done = collected >= int(mission.goal)
	if done:
		_win()


func _objective_text() -> String:
	match mission.type:
		"eliminate": return "Eliminate enemies  %d / %d" % [kills, int(mission.goal)]
		"eliminate_all": return "Eliminate all forces  %d / %d" % [kills, total_enemies]
		"commander": return "Defeat the commander" + ("  - DONE" if commander_dead else "")
		"civilians": return "Rescue civilians  %d / %d" % [collected, int(mission.goal)]
		"crates": return "Recover equipment  %d / %d" % [collected, int(mission.goal)]
		"reach":
			var d := player.global_position.distance_to(mission.marker)
			return "Reach the facility  %d m" % int(d)
		"hold":
			var pct := int(clampf(hold_progress / float(mission.hold_time), 0.0, 1.0) * 100.0)
			return "Disable comms tower (stand in zone)  %d%%" % pct
	return ""


func _freeze_world() -> void:
	_ended = true
	player.dead = true
	player.fire_held = false
	for e: Enemy in get_tree().get_nodes_in_group("enemies"):
		e.set_physics_process(false)


func _win() -> void:
	if _ended:
		return
	_freeze_world()
	var ratio := player.health / player.max_health
	var star_count := 3 if ratio >= 0.7 else (2 if ratio >= 0.35 else 1)
	var coin_reward := 100 + 50 * mission_index + star_count * 50 + kills * 10
	var xp_reward := 100 + 50 * mission_index
	GameData.complete_mission(mission_index, star_count, coin_reward, xp_reward)
	Sfx.play("victory")
	var buttons: Array = []
	if mission_index + 1 < Missions.LIST.size():
		buttons.append(["NEXT MISSION", _next_mission])
	buttons.append(["REPLAY", _retry])
	buttons.append(["MAIN MENU", _to_menu])
	_show_panel("MISSION COMPLETE", [
		mission.name, "Score  %d     Kills  %d" % [score, kills],
		"Stars  %d / 3" % star_count,
		"+%d coins     +%d XP" % [coin_reward, xp_reward]], buttons)


func _lose() -> void:
	if _ended:
		return
	_freeze_world()
	Sfx.play("defeat")
	_show_panel("MISSION FAILED", [mission.name, "Score  %d" % score],
			[["RETRY", _retry], ["MAIN MENU", _to_menu]])


func _retry() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()


func _next_mission() -> void:
	GameData.current_mission = mission_index + 1
	_retry()


func _to_menu() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://menu.tscn")


func _pause() -> void:
	if _ended or get_tree().paused:
		return
	player.fire_held = false
	player.aiming = false
	_was_captured = false
	get_tree().paused = true
	_show_panel("PAUSED", [], [["RESUME", _resume], ["QUIT TO MENU", _to_menu]])


func _resume() -> void:
	get_tree().paused = false
	if not _touch_visible:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	_was_captured = false
	if _panel:
		_panel.queue_free()
		_panel = null


# ---------- Input mode (touch vs desktop) ----------
func _setup_input_mode() -> void:
	_touch_visible = DisplayServer.is_touchscreen_available()
	for c in _touch_ui:
		c.visible = _touch_visible
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_hint.visible = not _touch_visible


func _input(event: InputEvent) -> void:
	# First real touch reveals the touch controls (hybrid devices)
	if not _touch_visible and event is InputEventScreenTouch:
		_touch_visible = true
		for c in _touch_ui:
			c.visible = true
		_hint.visible = false


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


# ---------- HUD ----------
func _build_hud() -> void:
	_layer = CanvasLayer.new()
	add_child(_layer)

	_flash = ColorRect.new()
	_flash.set_anchors_preset(Control.PRESET_FULL_RECT)
	_flash.color = Color(0.8, 0, 0, 0)
	_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_layer.add_child(_flash)

	var joy := VirtualJoystick.new()
	joy.anchor_top = 1.0
	joy.anchor_bottom = 1.0
	joy.offset_left = 50
	joy.offset_right = 290
	joy.offset_top = -290
	joy.offset_bottom = -50
	_layer.add_child(joy)
	_touch_ui.append(joy)
	joy.moved.connect(player.set_move_input)

	var fire := _touch_button("FIRE", 70, 140, 150)
	fire.button_down.connect(player.set_firing.bind(true))
	fire.button_up.connect(player.set_firing.bind(false))
	var jump := _touch_button("JUMP", 70, 20, 100)
	jump.button_down.connect(player.request_jump)
	_crouch_btn = _touch_button("CROUCH", 190, 20, 90)
	_crouch_btn.pressed.connect(player.toggle_crouch)
	var reload_btn := _touch_button("RELOAD", 240, 140, 90)
	reload_btn.button_down.connect(player.reload)
	var aim := _touch_button("AIM", 240, 240, 90)
	aim.button_down.connect(player.set_aiming.bind(true))
	aim.button_up.connect(player.set_aiming.bind(false))
	_sprint_btn = _touch_button("SPRINT", 70, 310, 90)
	_sprint_btn.pressed.connect(player.toggle_sprint)
	var camera_btn := _touch_button("CAM", 350, 20, 90)
	camera_btn.pressed.connect(player.toggle_camera_mode)

	# Crosshair
	var cross := Control.new()
	for a in ["anchor_left", "anchor_right", "anchor_top", "anchor_bottom"]:
		cross.set(a, 0.5)
	cross.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_layer.add_child(cross)
	for r in [Rect2(-18, -1, 12, 2), Rect2(6, -1, 12, 2), Rect2(-1, -18, 2, 12), Rect2(-1, 6, 2, 12)]:
		var cr := ColorRect.new()
		cr.position = r.position
		cr.size = r.size
		cr.color = Color(1, 1, 1, 0.85)
		cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		cross.add_child(cr)

	# Health bar (top-left) + mini-map under it
	_health_bar = ProgressBar.new()
	_health_bar.show_percentage = false
	_health_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_health_bar.offset_left = 30
	_health_bar.offset_top = 30
	_health_bar.offset_right = 330
	_health_bar.offset_bottom = 54
	_layer.add_child(_health_bar)

	var mm := Minimap.new()
	mm.player = player
	mm.offset_left = 30
	mm.offset_top = 70
	mm.offset_right = 200
	mm.offset_bottom = 240
	_layer.add_child(mm)

	_score_label = _label(26, HORIZONTAL_ALIGNMENT_CENTER)
	_score_label.anchor_left = 0.5
	_score_label.anchor_right = 0.5
	_score_label.offset_left = -200
	_score_label.offset_right = 200
	_score_label.offset_top = 14

	_objective_label = _label(22, HORIZONTAL_ALIGNMENT_CENTER)
	_objective_label.anchor_left = 0.5
	_objective_label.anchor_right = 0.5
	_objective_label.offset_left = -300
	_objective_label.offset_right = 300
	_objective_label.offset_top = 50

	_ammo_label = _label(26, HORIZONTAL_ALIGNMENT_RIGHT)
	_ammo_label.anchor_left = 1.0
	_ammo_label.anchor_right = 1.0
	_ammo_label.offset_left = -380
	_ammo_label.offset_right = -30
	_ammo_label.offset_top = 20

	_status_label = _label(32, HORIZONTAL_ALIGNMENT_CENTER)
	for a in ["anchor_left", "anchor_right", "anchor_top", "anchor_bottom"]:
		_status_label.set(a, 0.5)
	_status_label.offset_left = -350
	_status_label.offset_right = 350
	_status_label.offset_top = 70
	_status_label.offset_bottom = 170

	_hint = _label(24, HORIZONTAL_ALIGNMENT_CENTER)
	for a in ["anchor_left", "anchor_right", "anchor_top", "anchor_bottom"]:
		_hint.set(a, 0.5)
	_hint.offset_left = -450
	_hint.offset_right = 450
	_hint.offset_top = 190
	_hint.offset_bottom = 330
	_hint.text = "CLICK TO PLAY\nWASD move  |  Mouse look  |  Left click fire  |  Right click aim\nR reload  |  Space jump  |  Shift sprint  |  C / Ctrl crouch  |  V camera  |  Esc pause"

	var pause_btn := Button.new()
	pause_btn.text = "II"
	pause_btn.focus_mode = Control.FOCUS_NONE
	pause_btn.anchor_left = 1.0
	pause_btn.anchor_right = 1.0
	pause_btn.offset_left = -100
	pause_btn.offset_right = -30
	pause_btn.offset_top = 70
	pause_btn.offset_bottom = 130
	pause_btn.pressed.connect(_pause)
	_layer.add_child(pause_btn)
	_touch_ui.append(pause_btn)


func _label(font_size: int, align: HorizontalAlignment) -> Label:
	var l := Label.new()
	l.horizontal_alignment = align
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 6)
	_layer.add_child(l)
	return l


func _touch_button(text: String, from_right: float, from_bottom: float, px: float) -> TouchButton:
	var b := TouchButton.new()
	b.label = text
	b.anchor_left = 1.0
	b.anchor_right = 1.0
	b.anchor_top = 1.0
	b.anchor_bottom = 1.0
	b.offset_right = -from_right
	b.offset_left = -from_right - px
	b.offset_bottom = -from_bottom
	b.offset_top = -from_bottom - px
	_layer.add_child(b)
	_touch_ui.append(b)
	return b


func _show_panel(title: String, lines: Array, buttons: Array) -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if _hint:
		_hint.visible = false
	if _panel:
		_panel.queue_free()
	_panel = PanelContainer.new()
	_panel.process_mode = Node.PROCESS_MODE_ALWAYS
	for a in ["anchor_left", "anchor_right", "anchor_top", "anchor_bottom"]:
		_panel.set(a, 0.5)
	_panel.offset_left = -250
	_panel.offset_right = 250
	_panel.offset_top = -180
	_panel.offset_bottom = 180
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	_panel.add_child(v)
	var t := Label.new()
	t.text = title
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.add_theme_font_size_override("font_size", 36)
	v.add_child(t)
	for line in lines:
		var l := Label.new()
		l.text = str(line)
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.add_theme_font_size_override("font_size", 22)
		v.add_child(l)
	for b in buttons:
		var btn := Button.new()
		btn.text = b[0]
		btn.custom_minimum_size = Vector2(0, 56)
		btn.add_theme_font_size_override("font_size", 24)
		btn.pressed.connect(b[1])
		v.add_child(btn)
	_layer.add_child(_panel)


# ---------- HUD callbacks ----------
func _on_ammo_changed(mag: int, reserve: int) -> void:
	_ammo_label.text = "%s  %d / %d" % [player.weapon.weapon_name, mag, reserve]


func _on_health_changed(current: float, maximum: float) -> void:
	_health_bar.max_value = maximum
	_health_bar.value = current
	if current < _last_health:
		_flash.color.a = 0.35
		create_tween().tween_property(_flash, "color:a", 0.0, 0.4)
	_last_health = current
