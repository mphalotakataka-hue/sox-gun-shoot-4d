class_name VirtualJoystick
extends Control
## On-screen joystick. Emits `moved` with a Vector2 (x = right, y = down), length 0..1.

signal moved(vector: Vector2)

@export var max_distance_ratio := 0.35  # fraction of control width the knob can travel

var output := Vector2.ZERO
var _touch_index := -1
var _knob := Vector2.ZERO


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and _touch_index == -1:
			_touch_index = event.index
			_update(event.position)
			accept_event()
		elif not event.pressed and event.index == _touch_index:
			_reset()
			accept_event()
	elif event is InputEventScreenDrag and event.index == _touch_index:
		_update(event.position)
		accept_event()


func _update(local_pos: Vector2) -> void:
	var max_dist := size.x * max_distance_ratio
	var v := local_pos - size / 2.0
	if v.length() > max_dist:
		v = v.normalized() * max_dist
	_knob = v
	output = v / max_dist
	moved.emit(output)
	queue_redraw()


func _reset() -> void:
	_touch_index = -1
	_knob = Vector2.ZERO
	output = Vector2.ZERO
	moved.emit(output)
	queue_redraw()


func _draw() -> void:
	var c := size / 2.0
	draw_circle(c, size.x * 0.5, Color(1, 1, 1, 0.12))
	draw_arc(c, size.x * 0.5, 0.0, TAU, 48, Color(1, 1, 1, 0.35), 3.0)
	draw_circle(c + _knob, size.x * 0.18, Color(0.9, 0.15, 0.15, 0.75))
