extends Control
## Main menu: PLAY GAME, MISSIONS, CHARACTERS, WEAPONS, UPGRADES, SETTINGS, EXIT.

const UPGRADES := [
	["mag", "Magazine size  (+5 rounds)"],
	["damage", "Weapon damage  (+10%)"],
	["reload", "Reload speed  (-10% time)"],
]
const DIFFICULTY := ["Easy", "Medium", "Hard"]
const QUALITY := ["Low", "Medium", "High"]

var _col: VBoxContainer
var _info: Label
var _note: Label
var _reset_armed := false


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Sfx.play_music()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

	var bg := ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.05, 0.06, 0.08)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 40)
	add_child(margin)

	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 40)
	margin.add_child(hbox)

	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.alignment = BoxContainer.ALIGNMENT_CENTER
	hbox.add_child(left)
	var title := _lbl("ZOMA\nGUN SHOOT", 64)
	title.add_theme_color_override("font_color", Color(0.9, 0.15, 0.15))
	left.add_child(title)
	left.add_child(_lbl("Fight. Survive. Become the Legend.", 22))
	_info = _lbl("", 24)
	left.add_child(_info)
	_note = _lbl("", 22)
	_note.add_theme_color_override("font_color", Color(1, 0.8, 0.3))
	left.add_child(_note)

	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(560, 0)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	hbox.add_child(scroll)
	_col = VBoxContainer.new()
	_col.custom_minimum_size = Vector2(540, 0)
	_col.add_theme_constant_override("separation", 8)
	scroll.add_child(_col)

	_main()


func _lbl(text: String, size: int) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l


func _btn(text: String, cb: Callable, disabled := false) -> Button:
	var b := Button.new()
	b.text = text
	b.disabled = disabled
	b.custom_minimum_size = Vector2(0, 60)
	b.add_theme_font_size_override("font_size", 24)
	b.pressed.connect(cb)
	_col.add_child(b)
	return b


func _clear() -> void:
	for c in _col.get_children():
		_col.remove_child(c)
		c.queue_free()
	_note.text = ""
	_info.text = "LEVEL %d     XP %d\nCOINS %d" % [GameData.level(), GameData.xp, GameData.coins]


func _back() -> void:
	GameData.save_data()
	_main()


# ---------- Screens ----------
func _main() -> void:
	_clear()
	_reset_armed = false
	_btn("PLAY GAME", func(): _start(GameData.unlocked_missions - 1))
	_btn("MISSIONS", _missions)
	_btn("CHARACTERS", _characters)
	_btn("WEAPONS", _weapons)
	_btn("UPGRADES", _upgrades)
	_btn("SETTINGS", _settings)
	if not OS.has_feature("web"):
		_btn("EXIT", func(): get_tree().quit())


func _start(i: int) -> void:
	GameData.current_mission = clampi(i, 0, Missions.LIST.size() - 1)
	get_tree().change_scene_to_file("res://main.tscn")


func _missions() -> void:
	_clear()
	for i in Missions.LIST.size():
		var m: Dictionary = Missions.LIST[i]
		var s := int(GameData.stars.get(str(i), 0))
		var locked := i >= GameData.unlocked_missions
		var text := "%02d  %s" % [i + 1, m.name]
		text += "     LOCKED" if locked else "     stars %d/3" % s
		_btn(text, _start.bind(i), locked)
	_btn("BACK", _back)


func _characters() -> void:
	_clear()
	_btn("ZOMA - The Commander   (selected)", func(): _note.text = "Assault rifle, tactical focus.")
	for c in ["NAYA - The Sniper", "TITAN - The Heavy Soldier", "SHADOW - The Stealth Expert",
			"KITO - The Assault Specialist", "REX - The Combat Robot"]:
		_btn(c + "   (coming soon)", func(): pass, true)
	_btn("BACK", _back)


func _weapons() -> void:
	_clear()
	_btn("ZR-01  Assault rifle   (equipped)", func(): _note.text = "Standard combat. Upgrade it in UPGRADES.")
	for w in ["Viper-9  SMG", "Thunder  Shotgun", "Eagle-50  Sniper rifle", "Falcon  Pistol", "Titan MG  Machine gun"]:
		_btn(w + "   (coming soon)", func(): pass, true)
	_btn("BACK", _back)


func _upgrades() -> void:
	_clear()
	for u in UPGRADES:
		var key: String = u[0]
		var lvl := int(GameData.upgrades[key])
		var maxed := lvl >= GameData.UPGRADE_MAX
		var text := "%s\nLv %d/%d    %s" % [u[1], lvl, GameData.UPGRADE_MAX,
				"MAX" if maxed else "%d coins" % GameData.upgrade_cost(key)]
		var b := _btn(text, _buy.bind(key), maxed)
		b.custom_minimum_size = Vector2(0, 84)
	_btn("BACK", _back)


func _buy(key: String) -> void:
	if GameData.buy_upgrade(key):
		Sfx.play("pickup")
		_upgrades()
		_note.text = "Upgrade purchased!"
	else:
		_note.text = "Not enough coins."


func _settings() -> void:
	_clear()
	var d := _btn("", func(): pass)
	d.text = "Difficulty:  %s" % DIFFICULTY[int(GameData.settings["difficulty"])]
	d.pressed.connect(func():
		GameData.settings["difficulty"] = (int(GameData.settings["difficulty"]) + 1) % 3
		d.text = "Difficulty:  %s" % DIFFICULTY[int(GameData.settings["difficulty"])])

	var q := _btn("", func(): pass)
	q.text = "Graphics:  %s" % QUALITY[int(GameData.settings["quality"])]
	q.pressed.connect(func():
		GameData.settings["quality"] = (int(GameData.settings["quality"]) + 1) % 3
		q.text = "Graphics:  %s" % QUALITY[int(GameData.settings["quality"])])

	_slider("Look sensitivity", "sensitivity", 0.4, 2.0)
	_slider("Music volume", "music", 0.0, 1.0)
	_slider("Effects volume", "sfx", 0.0, 1.0)

	var r := _btn("RESET PROGRESS", func(): pass)
	r.pressed.connect(func():
		if _reset_armed:
			GameData.reset_progress()
			_reset_armed = false
			_note.text = "Progress reset."
			r.text = "RESET PROGRESS"
		else:
			_reset_armed = true
			r.text = "TAP AGAIN TO CONFIRM")
	_btn("BACK", _back)


func _slider(label: String, key: String, lo: float, hi: float) -> void:
	_col.add_child(_lbl(label, 20))
	var s := HSlider.new()
	s.min_value = lo
	s.max_value = hi
	s.step = 0.05
	s.value = float(GameData.settings[key])
	s.custom_minimum_size = Vector2(0, 40)
	s.value_changed.connect(func(v: float):
		GameData.settings[key] = v
		Sfx.apply_volumes())
	_col.add_child(s)
