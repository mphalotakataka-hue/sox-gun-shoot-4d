class_name MissionMarker
extends Area3D
## Mission objects: captured civilian, stolen crate, or a glowing zone (reach / hold).

enum Kind { CIVILIAN, CRATE, ZONE }

signal collected(marker: MissionMarker)

@export var kind: Kind = Kind.ZONE
@export var zone_radius := 4.0
@export var emit_on_enter := true   # false for "hold" zones (the game polls player_inside)

var player_inside := false


func _ready() -> void:
	collision_layer = 0
	collision_mask = 1
	var cs := CollisionShape3D.new()
	var mi := MeshInstance3D.new()
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED

	match kind:
		Kind.CIVILIAN:
			add_to_group("civilians")
			var sh := SphereShape3D.new()
			sh.radius = 1.5
			cs.shape = sh
			cs.position.y = 0.9
			var cap := CapsuleMesh.new()
			cap.radius = 0.3
			cap.height = 1.6
			mat.albedo_color = Color(0.2, 0.6, 1.0)
			cap.material = mat
			mi.mesh = cap
			mi.position.y = 0.8
		Kind.CRATE:
			add_to_group("objective")
			var sh := SphereShape3D.new()
			sh.radius = 1.5
			cs.shape = sh
			cs.position.y = 0.5
			var bm := BoxMesh.new()
			bm.size = Vector3(0.9, 0.9, 0.9)
			mat.albedo_color = Color(1.0, 0.8, 0.1)
			bm.material = mat
			mi.mesh = bm
			mi.position.y = 0.5
		Kind.ZONE:
			add_to_group("objective")
			var sh := CylinderShape3D.new()
			sh.radius = zone_radius
			sh.height = 4.0
			cs.shape = sh
			cs.position.y = 2.0
			var cyl := CylinderMesh.new()
			cyl.top_radius = zone_radius
			cyl.bottom_radius = zone_radius
			cyl.height = 5.0
			mat.albedo_color = Color(1.0, 0.85, 0.1, 0.22)
			mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			mat.cull_mode = BaseMaterial3D.CULL_DISABLED
			cyl.material = mat
			mi.mesh = cyl
			mi.position.y = 2.5
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(cs)
	add_child(mi)
	body_entered.connect(_on_enter)
	body_exited.connect(_on_exit)


func _process(delta: float) -> void:
	if kind == Kind.CRATE:
		rotation.y += delta


func _on_enter(body: Node3D) -> void:
	if not (body is Player):
		return
	player_inside = true
	if emit_on_enter:
		collected.emit(self)


func _on_exit(body: Node3D) -> void:
	if body is Player:
		player_inside = false
