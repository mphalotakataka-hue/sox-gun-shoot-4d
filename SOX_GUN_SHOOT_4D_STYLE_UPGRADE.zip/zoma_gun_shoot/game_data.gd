extends Node
## Autoload "GameData": coins, XP, mission progress, upgrades, settings. Saved locally (offline).

const SAVE_PATH := "user://zoma_save.json"
const MISSION_COUNT := 7
const UPGRADE_MAX := 5

var coins := 0
var xp := 0
var unlocked_missions := 1
var stars: Dictionary = {}
var upgrades: Dictionary = {"mag": 0, "damage": 0, "reload": 0}
var settings: Dictionary = {
	"difficulty": 1,      # 0 easy, 1 medium, 2 hard
	"quality": 1,         # 0 low, 1 medium, 2 high
	"sensitivity": 1.0,
	"music": 0.5,
	"sfx": 0.9,
}
var current_mission := 0


func _ready() -> void:
	load_data()


func level() -> int:
	return floori(xp / 250.0) + 1


func diff_mult() -> float:
	return [0.6, 1.0, 1.4][int(settings["difficulty"])]


func upgrade_cost(key: String) -> int:
	return 100 * (int(upgrades[key]) + 1)


func buy_upgrade(key: String) -> bool:
	var lvl := int(upgrades[key])
	if lvl >= UPGRADE_MAX or coins < upgrade_cost(key):
		return false
	coins -= upgrade_cost(key)
	upgrades[key] = lvl + 1
	save_data()
	return true


func complete_mission(idx: int, star_count: int, coin_reward: int, xp_reward: int) -> void:
	coins += coin_reward
	xp += xp_reward
	var k := str(idx)
	stars[k] = maxi(int(stars.get(k, 0)), star_count)
	unlocked_missions = mini(maxi(unlocked_missions, idx + 2), MISSION_COUNT)
	save_data()


func reset_progress() -> void:
	coins = 0
	xp = 0
	unlocked_missions = 1
	stars = {}
	upgrades = {"mag": 0, "damage": 0, "reload": 0}
	save_data()


func save_data() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify({
		"coins": coins, "xp": xp, "unlocked": unlocked_missions,
		"stars": stars, "upgrades": upgrades, "settings": settings,
	}))


func load_data() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var data = JSON.parse_string(f.get_as_text())
	if not (data is Dictionary):
		return
	coins = int(data.get("coins", 0))
	xp = int(data.get("xp", 0))
	unlocked_missions = clampi(int(data.get("unlocked", 1)), 1, MISSION_COUNT)
	stars = data.get("stars", {})
	for k in upgrades.keys():
		upgrades[k] = int(data.get("upgrades", {}).get(k, 0))
	var s: Dictionary = data.get("settings", {})
	for k in settings.keys():
		if s.has(k):
			settings[k] = s[k]
